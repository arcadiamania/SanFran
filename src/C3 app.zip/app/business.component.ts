import { Component } from '@angular/core';
import { WebService } from './web.service';//C2,5
import { ActivatedRoute } from '@angular/router';//C2,20

@Component({//C2,16
  selector: 'business',
  templateUrl: './business.component.html',
  styleUrls: ['./business.component.css']
})
export class BusinessComponent {
	
	constructor(//C2,6
		private webService: WebService,
		private route: ActivatedRoute//C2,20
	){}
	
	/*C3,3
	async ngOnInit(){//C2,6
		var response = await this.webService.getBusiness(this.route.snapshot.params.id);//C2,16 //C2,20
		this.business_list = [response];//C2,16
	}*/
	
	ngOnInit(){
		this.webService.getBusiness(this.route.snapshot.params.id);
	}//C3,10
	
	//C3,10 business_list;//C2,16

}
