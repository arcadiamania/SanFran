import {HttpClient} from '@angular/common/http';
import {Injectable} from '@angular/core';
import {Subject} from 'rxjs';//C3,6

@Injectable()
export class WebService {
	private business_private_list;//C3,8
	private businessesSubject = new Subject();//C3,6//C3,8
	business_list = this.businessesSubject.asObservable();//C3,8
	
	constructor(
		private http: HttpClient
	){}
	
	getBusinesses(page){
		return this.http.get(
			'http://localhost:5000/api/v1.0/businesses?pn='+page
		).subscribe(response => {
			this.business_private_list = response; //C3,8
			this.businessesSubject.next(this.business_private_list);//C3,6//C3,8
		});//C3,4
		
		
		//C3,3 .toPromise();
	}
	
	/*C3,2
	getBusiness(id){//C2,17
		return this.http.get(
			'http://localhost:5000/api/v1.0/businesses/'+id
		).toPromise();
	}*/
	
	getBusiness(id){//C3,10
		return this.http.get(
			'http://localhost:5000/api/v1.0/businesses/'+id
		).subscribe(response => {
			this.business_private_list = [response];
			this.businessesSubject.next(this.business_private_list);
		});
	}
}